﻿
using Exercise3.Handlers;

Menu Menuett = new Menu();  // Menuett är f.ö. en dansrytm i lugn tre fjärdedelstakt ...
Menuett.ShowMenu();
Menuett.GetMenuItem();


